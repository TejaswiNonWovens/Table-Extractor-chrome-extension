chrome.runtime.onInstalled.addListener(() => {
  console.log("Inventory Exporter installed.");
});
