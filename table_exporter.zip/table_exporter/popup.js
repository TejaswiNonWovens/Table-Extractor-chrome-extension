document.getElementById("exportBtn").addEventListener("click", async () => {
  chrome.scripting.executeScript({
    target: { tabId: (await chrome.tabs.query({ active: true, currentWindow: true }))[0].id },
    func: scrapeAndDownload
  });
}); 

function scrapeAndDownload() {
  const rows = Array.from(document.querySelectorAll("table tr"));
  const cleaned = rows.map(row => {
    const cells = Array.from(row.querySelectorAll("td,th"))
      .map(cell => cell.innerText.trim())
      .filter((_, index) => index !== 9 && index !== 10); // Exclude columns 10 & 11
    return cells;
  });

  const csv = cleaned.map(r => r.join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;

  // ✅ IST timestamp using toLocaleString
  const istString = new Date().toLocaleString("en-GB", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  });

  // Convert "19/07/2025, 01:11:23" → "20250719_011123"
  const [datePart, timePart] = istString.split(", ");
  const [day, month, year] = datePart.split("/");
  const [hour, minute, second] = timePart.split(":");
  const timestamp = `${year}${month}${day}_${hour}${minute}${second}`;

  a.download = `inventory-export-${timestamp}.csv`;

  document.body.appendChild(a);
  a.click();
  a.remove();
}